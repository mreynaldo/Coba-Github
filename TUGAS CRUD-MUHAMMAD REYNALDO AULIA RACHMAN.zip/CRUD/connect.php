<?php 
    $db = mysqli_connect("localhost", "root", "" , "perpustakaan") or die("Gagal Bray");
?>
